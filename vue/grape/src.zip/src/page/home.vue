<template>
    <div>
        <Item father-com="home"></Item>    
    </div>    
</template>

<script>
import Item from "../components/item"
export default {
    components:{Item}
}
</script>

<style>

</style>

