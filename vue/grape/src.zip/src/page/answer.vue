<template>
    <div>
        <Item father-com="answer">answer</Item>    
    </div>    
</template>

<script>
import Item from "../components/item"
export default {
    components:{Item}
}
</script>

<style>

</style>

